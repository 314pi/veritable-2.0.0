//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PassDialog.rc
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     102
#define IDD_DIALOG3                     103
#define IDD_DIALOG4                     104
#define IDC_GROUPBOX                    1210
#define IDC_LABELH                      1211
#define IDC_LABELA                      1212
#define IDC_LABELB                      1213
#define IDC_PASSWORD                    1214
#define IDC_SERIAL                      1215
#define IDC_USERNAME                    1215
#define IDC_INPUTBOX                    1215

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1217
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
